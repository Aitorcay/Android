/**
 * IMPORTANT: Make sure you are using the correct package name.
 * This example uses the package name:
 * package com.example.android.justjava
 * If you get an error when copying this code into Android studio, update it to match teh package name found
 * in the project's AndroidManifest.xml file.
 **/

package com.example.usuario.justjava;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.usuario.justjava.R;

import java.text.NumberFormat;

/**
 * This app displays an order form to order coffee.
 */
public class MainActivity extends AppCompatActivity {

    private int quantity = 1;
    private int cost = 5;
    private int costWhippedCream = 1;
    private int costChocolate = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * This method is called when the order button is clicked.
     */
    public void submitOrder(View view) {
        boolean whippedCream = hasWhippedCream();
        boolean chocolate = hasChocolate();
        int price = calculatePrice(whippedCream, chocolate);
        String name = getName();
        String message = createOrderSummary(price, whippedCream, chocolate, name);
        displayMessage(message);
        sendOrder();
    }

    /**
     * This method is called when the + button is clicked.
     */
    public void increment(View view) {
        if (quantity < 100) {
            quantity = quantity + 1;
            displayQuantity(quantity);
        }

        else {
            Toast.makeText(this, R.string.max, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * This method is called when the - button is clicked.
     */
    public void decrement(View view) {
        if (quantity > 1) {
            quantity = quantity - 1;
            displayQuantity(quantity);
        }

        else {
            Toast.makeText(this, R.string.min, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * This method displays the given quantity value on the screen.
     */
    private void displayQuantity(int quantity) {
        TextView quantityTextView = (TextView) findViewById(R.id.quantity_text_view);
        quantityTextView.setText("" + quantity);
    }

    /**
     * This method displays the given text on the screen.
     */
    private void displayMessage(String message) {
        TextView orderSummaryTextView = (TextView) findViewById(R.id.order_summary_text_view);
        orderSummaryTextView.setText(message);
    }

    /**
     * Checks if the customer has ordered whipped cream
     */
    private boolean hasWhippedCream() {
        CheckBox checkbox = (CheckBox) findViewById(R.id.whipped_cream_checkbox);
        boolean cream = checkbox.isChecked();
        return cream;
    }

    /**
     * Checks if the customer has ordered chocolate
     */
    private boolean hasChocolate() {
        CheckBox checkbox = (CheckBox) findViewById(R.id.chocolate_checkbox);
        boolean chocolate = checkbox.isChecked();
        return chocolate;
    }

    /**
     * Gets the name of the customer
     */
    private String getName() {
        EditText nameField = (EditText) findViewById(R.id.name_field);
        String name = nameField.getText().toString();
        return name;
    }

    /**
     * Calculates the price of the order based on the current quantity.
     *
     * @return the price
     */
    private int calculatePrice(boolean whippedCream, boolean chocolate) {
        int whippedCreamCharge = 0;
        int chocolateCharge = 0;

        if (whippedCream) {
            whippedCreamCharge = quantity * costWhippedCream;
        }

        if (chocolate) {
            chocolateCharge = quantity * costChocolate;
        }

        int price = quantity * cost + whippedCreamCharge + chocolateCharge;
        return price;
    }

    /**
     * Create summary of the order.
     *
     * @param cream is whether or not the user wants whipped cream topping
     * @param chocolate is whether or not the user wants chocolate topping
     * @param price of the order
     * @return text summary
     */
    private String createOrderSummary(int price, boolean cream, boolean chocolate, String name) {
        String priceMessage = "Name: " + name;
        priceMessage += "\nAdd whipped cream?: " + cream;
        priceMessage += "\nAdd chocolate?: " + chocolate;
        priceMessage += "\nQuantity: " + quantity;
        priceMessage += "\nTotal: $" + price;
        priceMessage += "\nThank you!";
        return priceMessage;
    }

    /**
     * This method is called when the - button is clicked.
     */
    public void sendOrder() {
        TextView orderSummaryTextView = (TextView) findViewById(R.id.order_summary_text_view);
        String orderSummary = orderSummaryTextView.getText().toString();
        String[] addresses = new String[] { "insertar correo" };

        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:"));
        intent.putExtra(Intent.EXTRA_EMAIL, addresses);
        intent.putExtra(Intent.EXTRA_SUBJECT, "Just Java order");
        intent.putExtra(Intent.EXTRA_TEXT, orderSummary);
        intent.setType("text/plain");

        if(intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }
}