package com.example.android.miwok;

public class Word {
    private String mikowTranslation;
    private String defaultTranslation;
    private int imageResourceId = NO_IMAGE_PROVIDED;
    private int audioResourceId = NO_IMAGE_PROVIDED;

    private static final int NO_IMAGE_PROVIDED = -1;

    public Word(String mikowTranslation, String defaultTranslation, int soundResourceId) {
        this.mikowTranslation = mikowTranslation;
        this.defaultTranslation = defaultTranslation;
        this.audioResourceId = soundResourceId;
    }

    public Word(String mikowTranslation, String defaultTranslation, int imageResourceId, int soundResourceId) {
        this.mikowTranslation = mikowTranslation;
        this.defaultTranslation = defaultTranslation;
        this.imageResourceId = imageResourceId;
        this.audioResourceId = soundResourceId;
    }

    public String getMiwokTranslation() {
        return this.mikowTranslation;
    }

    public String getDefaultTranslation() {
        return this.defaultTranslation;
    }

    public int getImageResourceId() {
        return this.imageResourceId;
    }

    public boolean hasImage() {return this.imageResourceId != NO_IMAGE_PROVIDED; }

    public int getAudioResourceId() {
        return this.audioResourceId;
    }

}
