package usuario.example.com.test;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final String TOTAL_COUNT = "total_count";

    /**
     * -------------------------------------------------------    AUXILIAR FUNCTIONS    -------------------------------------------------------
     */


    /**
     * -------------------------------------------------------    FUNCTIONS    -------------------------------------------------------
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * Show a toast
     * @param view -- the view that is clicked
     */
    public void toastMe(View view){
        // Toast myToast = Toast.makeText(this, message, duration);
        Toast myToast = Toast.makeText(this, "Hello Toast!",
                Toast.LENGTH_SHORT);
        myToast.show();
    }

    /**
     * Increases the shown number by 1
     * @param view -- the view that is clicked
     */
    public void countMe (View view) {
        // Get the text view
        TextView count = (TextView) findViewById(R.id.textView);
        // Get the value of the text view.
        String countString = count.getText().toString();
        // Convert value to a number and increment it
        Integer num = Integer.parseInt(countString);
        num++;
        // Display the new value in the text view.
        count.setText(num.toString());
    }

    /**
     * Generates a random number
     * @param view -- the view that is clicked
     */
    public void randomMe (View view) {
        // Create an Intent to start the second activity
        Intent randomIntent = new Intent(this, TestRandom.class);
        // Get the text view
        TextView count = (TextView) findViewById(R.id.textView);
        // Get the value of the text view.
        String countString = count.getText().toString();
        // Convert value to a number and increment it
        int num = Integer.parseInt(countString);
        // Add the count to the extras for the Intent
        randomIntent.putExtra(TOTAL_COUNT, num);
        // Start the new activity.
        startActivity(randomIntent);
    }
}
